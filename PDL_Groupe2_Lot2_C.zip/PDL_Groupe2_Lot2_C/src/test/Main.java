package test;

import gui.Authentification;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Authentification id = new Authentification();
		id.setVisible(true);
		

	}

}
