package dao;

public class CoursDAO {

}
