package dao;


public class ConnectionBDD {

    //String URL = "jdbc:oracle:thin:@//srvoracledb.intranet.int:1521/orcl.intranet.
    //final static String URL= "jdbc:oracle:thin:@//192.168.4.183:1521/orcl.intranet.int";
    public final static String URL = "jdbc:oracle:thin:@//oracle.esigelec.fr:1521/orcl.intranet.int";
    public final static String LOGIN = "C##_G2_G2_APP";
    public final static String PWD = "APP_2_2";
    
    /*public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(URL, LOGIN, PWD);
    	
    }*/
    
}















