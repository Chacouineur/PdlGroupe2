package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConnexionDAO extends ConnectionBDD{
	public ConnexionDAO() {
		super();
	}
	
	public int[] getConnexion(String email, String mdp) throws Exception {
		try (Connection con = DriverManager.getConnection(URL, LOGIN, PWD);) {
			int[] returnValue = {-1,-1};
			String[] tabStatement = new String[]{
				"SELECT * FROM Lot1_Etudiant WHERE etud_email = ? AND etud_mdp = ?",
				"SELECT * FROM Lot1_Enseignant WHERE ens_email = ? AND ens_mdp = ?",
				"SELECT * FROM Lot1_Administrateur WHERE adm_email = ? AND adm_mdp = ?",
				"SELECT * FROM Lot1_Gestionnaire WHERE gest_email = ? AND gest_mdp = ?"
			};
			
			for(int i = 0; i<4; i++) {
				PreparedStatement ps = con.prepareStatement(tabStatement[i]);
				ps.setString(1, email);
				ps.setString(2, mdp);
				
				// on execute la requete
				// rs contient un pointeur situe juste avant la premiere ligne retournee
				ResultSet rs = ps.executeQuery();
				// passe a la premiere (et unique) ligne retournee
				if (rs.next()) {
					returnValue[0] = i;
					switch(i) {
					case 0:
						returnValue[1] = rs.getInt("id_etudiant");
						break;
					case 1:
						returnValue[1] = rs.getInt("id_enseignant");
						break;
					case 2:
						returnValue[1] = rs.getInt("id_admin");
						break;
					case 3:
						returnValue[1] = rs.getInt("id_gestion	");
						break;
					}
				}
			}
		return returnValue;
		}
	}
}
