package dao;

public class GestionnaireDAO {

}
