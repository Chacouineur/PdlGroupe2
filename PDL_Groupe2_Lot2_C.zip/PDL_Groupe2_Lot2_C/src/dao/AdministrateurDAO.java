package dao;

public class AdministrateurDAO {

}
