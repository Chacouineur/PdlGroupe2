package dao;

public class AbsenceDAO {

}
