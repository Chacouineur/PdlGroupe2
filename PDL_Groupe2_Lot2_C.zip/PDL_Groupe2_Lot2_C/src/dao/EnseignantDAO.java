package dao;

public class EnseignantDAO {

}
