package dao;


import java.sql.*;


import model.Etudiant;

public class EtudiantDAO {
	
	
	private static final String CREATE_ETUDIANT_QUERY = "INSERT INTO Etudiant(id_etudiant,nom,prenom,adresse_mail,mdp,filiere,groupe) VALUES(?,?,?,?,?,?,?);";
	
	
	public long create(Etudiant etudiant) {
		try (Connection connection = ConnectionBDD.getConnection()){
			PreparedStatement stmt = connection.prepareStatement(CREATE_ETUDIANT_QUERY,Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1,etudiant.get());
			stmt.setString(1,etudiant.getAdresseElectronique());
			stmt.setString(1,etudiant.getAdresseElectronique());
			stmt.setString(1,etudiant.getAdresseElectronique());
			stmt.execute();
			ResultSet res = stmt.getGeneratedKeys();
			long id = 0;
			if (res.next()) {
				id = res.getLong(1);
			}
			return id;
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
