package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProfilEtudiant extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frmProfilEleve;
	private JTextField nom_textField;
	private JTextField prenom_textField;
	private JTextField email_textField;
	private JTextField groupe_textField;
	private JPasswordField passwordField;
	private ButtonGroup btnGroup;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfilEtudiant window = new ProfilEtudiant();
					window.frmProfilEleve.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ProfilEtudiant() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProfilEleve = new JFrame();
		frmProfilEleve.setTitle("Profil Elève");
		frmProfilEleve.setBounds(100, 100, 548, 307);
		frmProfilEleve.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frmProfilEleve.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		nom_textField = new JTextField();
		nom_textField.setEditable(false);
		nom_textField.setColumns(10);
		nom_textField.setBounds(51, 47, 197, 19);
		panel.add(nom_textField);
		
		JLabel nom = new JLabel("Nom");
		nom.setBounds(51, 30, 104, 13);
		panel.add(nom);
		
		prenom_textField = new JTextField();
		prenom_textField.setEditable(false);
		prenom_textField.setColumns(10);
		prenom_textField.setBounds(303, 47, 197, 19);
		panel.add(prenom_textField);
		
		JLabel prenom = new JLabel("Prénom");
		prenom.setBounds(303, 30, 104, 13);
		panel.add(prenom);
		
		JRadioButton rdbtnClassique = new JRadioButton("Classique");
		rdbtnClassique.setSelected(true);
		rdbtnClassique.setBounds(52, 95, 103, 21);
		rdbtnClassique.setEnabled(false);
		panel.add(rdbtnClassique);
		
		JRadioButton rdbtnApprentissage = new JRadioButton("Apprentissage");
		rdbtnApprentissage.setSelected(true);
		rdbtnApprentissage.setBounds(193, 95, 103, 21);
		rdbtnApprentissage.setEnabled(false);
		panel.add(rdbtnApprentissage);
		
		JLabel filiere = new JLabel("Filière");
		filiere.setBounds(51, 76, 45, 13);
		panel.add(filiere);
		
		email_textField = new JTextField();
		email_textField.setEditable(false);
		email_textField.setColumns(10);
		email_textField.setBounds(51, 139, 197, 19);
		panel.add(email_textField);
		
		JLabel email = new JLabel("Email");
		email.setBounds(51, 122, 104, 13);
		panel.add(email);
		
		groupe_textField = new JTextField();
		groupe_textField.setEditable(false);
		groupe_textField.setColumns(10);
		groupe_textField.setBounds(51, 185, 197, 19);
		panel.add(groupe_textField);
		
		JLabel groupe = new JLabel("Groupe");
		groupe.setBounds(51, 168, 104, 13);
		panel.add(groupe);
		
		JLabel motDePasse = new JLabel("Mot de passe");
		motDePasse.setBounds(51, 214, 104, 13);
		panel.add(motDePasse);
		
		JButton btnModifierInfos = new JButton("Modifier");
		
		btnModifierInfos.setBounds(351, 138, 149, 21);
		panel.add(btnModifierInfos);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnRetour.setBounds(415, 233, 85, 21);
		panel.add(btnRetour);
		
		passwordField = new JPasswordField();
		passwordField.setEditable(false);
		passwordField.setBounds(51, 234, 197, 19);
		panel.add(passwordField);
		
		btnGroup = new ButtonGroup();
		btnGroup.add(rdbtnClassique);
		btnGroup.add(rdbtnApprentissage);
		
		JButton btnConfirmer = new JButton("Confirmer");
		btnConfirmer.setVisible(false);
		btnConfirmer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(false);
				groupe_textField.setEditable(false);
				passwordField.setEditable(false);
				btnModifierInfos.setVisible(true);
				btnConfirmer.setVisible(false);
				rdbtnClassique.setEnabled(false);
				rdbtnApprentissage.setEnabled(false);
			}
		});
		btnConfirmer.setBounds(351, 184, 149, 21);
		panel.add(btnConfirmer);
		
		
		
		btnModifierInfos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(true);
				groupe_textField.setEditable(true);
				passwordField.setEditable(true);
				btnModifierInfos.setVisible(false);
				btnConfirmer.setVisible(true);
				rdbtnClassique.setEnabled(true);
				rdbtnApprentissage.setEnabled(true);
				
			}
		});
		
	}
}
