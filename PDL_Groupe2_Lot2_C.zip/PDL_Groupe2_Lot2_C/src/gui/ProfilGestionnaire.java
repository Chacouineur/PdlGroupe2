package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProfilGestionnaire {

	private JFrame ProfilAdministrateur;
	private JTextField nom_textField;
	private JTextField prenom_textField;
	private JTextField email_textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfilGestionnaire window = new ProfilGestionnaire();
					window.ProfilAdministrateur.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ProfilGestionnaire() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		ProfilAdministrateur = new JFrame();
		ProfilAdministrateur.setTitle("Profil Gestionnaire");
		ProfilAdministrateur.setBounds(100, 100, 497, 284);
		ProfilAdministrateur.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ProfilAdministrateur.getContentPane().setLayout(null);
		
		JLabel nom = new JLabel("Nom");
		nom.setBounds(30, 31, 223, 13);
		ProfilAdministrateur.getContentPane().add(nom);
		
		nom_textField = new JTextField();
		nom_textField.setEditable(false);
		nom_textField.setColumns(10);
		nom_textField.setBounds(30, 54, 203, 19);
		ProfilAdministrateur.getContentPane().add(nom_textField);
		
		JLabel prenom = new JLabel("Prénom");
		prenom.setBounds(30, 83, 203, 13);
		ProfilAdministrateur.getContentPane().add(prenom);
		
		prenom_textField = new JTextField();
		prenom_textField.setEditable(false);
		prenom_textField.setColumns(10);
		prenom_textField.setBounds(30, 106, 203, 19);
		ProfilAdministrateur.getContentPane().add(prenom_textField);
		
		JLabel email = new JLabel("Email");
		email.setBounds(30, 135, 185, 13);
		ProfilAdministrateur.getContentPane().add(email);
		
		email_textField = new JTextField();
		email_textField.setEditable(false);
		email_textField.setColumns(10);
		email_textField.setBounds(30, 158, 203, 19);
		ProfilAdministrateur.getContentPane().add(email_textField);
		
		JLabel mdp = new JLabel("Mot de passe");
		mdp.setBounds(30, 187, 165, 13);
		ProfilAdministrateur.getContentPane().add(mdp);
		
		passwordField = new JPasswordField();
		passwordField.setEditable(false);
		passwordField.setBounds(30, 210, 203, 19);
		ProfilAdministrateur.getContentPane().add(passwordField);
		
		JButton btnModifierInfos = new JButton("Modifier");
		
		btnModifierInfos.setBounds(307, 105, 165, 21);
		ProfilAdministrateur.getContentPane().add(btnModifierInfos);
		
		JButton btnConfirmer = new JButton("Confirmer");
		btnConfirmer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(false);
				passwordField.setEditable(false);
				btnConfirmer.setVisible(false);
				btnModifierInfos.setVisible(true);
			}
		});
		btnConfirmer.setVisible(false);
		btnConfirmer.setBounds(307, 157, 165, 21);
		ProfilAdministrateur.getContentPane().add(btnConfirmer);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MenuGestionnaire();
				ProfilAdministrateur.dispose();
			}
		});
		btnRetour.setBounds(353, 209, 119, 21);
		ProfilAdministrateur.getContentPane().add(btnRetour);
		
		btnModifierInfos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(true);
				passwordField.setEditable(true);
				btnConfirmer.setVisible(true);
				btnModifierInfos.setVisible(false);
			}
		});
	}

}
