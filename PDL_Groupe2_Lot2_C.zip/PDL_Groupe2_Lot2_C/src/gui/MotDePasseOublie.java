package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MotDePasseOublie {


	private JFrame frmMotDePasse;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MotDePasseOublie window = new MotDePasseOublie();
					window.frmMotDePasse.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MotDePasseOublie() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMotDePasse = new JFrame();
		frmMotDePasse.setTitle("Mot de passe oublié?");
		frmMotDePasse.setBounds(100, 100, 545, 277);
		frmMotDePasse.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMotDePasse.setVisible(true);
		
		JPanel panel = new JPanel();
		frmMotDePasse.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Entrez votre email");
		lblNewLabel.setBounds(84, 22, 96, 13);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(84, 45, 197, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Nouveau mot de passe");
		lblNewLabel_1.setBounds(84, 89, 104, 13);
		panel.add(lblNewLabel_1);
		
		JLabel lblConfirme = new JLabel("Confirmez le nouveau mot de passe");
		lblConfirme.setBounds(84, 156, 164, 13);
		panel.add(lblConfirme);
		
		JButton btnNewButton = new JButton("Confirmer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Authentification();
				frmMotDePasse.dispose();
			}
		});
		btnNewButton.setBounds(370, 85, 104, 21);
		panel.add(btnNewButton);
		
		JButton btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Authentification();
				frmMotDePasse.dispose();
			}
		});
		btnAnnuler.setBounds(370, 134, 104, 21);
		panel.add(btnAnnuler);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(84, 112, 197, 19);
		panel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(84, 179, 197, 19);
		panel.add(passwordField_1);
	}

}
