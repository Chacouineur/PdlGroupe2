package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import dao.ConnexionDAO;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Authentification extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Authentification window = new Authentification();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Authentification() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Authentification");
		frame.getContentPane().setLayout(new GridLayout(0, 1, 0, 0));
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblText = new JLabel("Entrez votre identifiant et votre mot de passe");
		lblText.setFont(new Font("Dialog", Font.PLAIN, 14));
		lblText.setBounds(71, 10, 315, 29);
		panel.add(lblText);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEmail.setBounds(54, 67, 125, 19);
		panel.add(lblEmail);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(54, 96, 278, 19);
		panel.add(textField);
		
		JLabel lblMdp = new JLabel("Mot de passe");
		lblMdp.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMdp.setBounds(54, 131, 125, 19);
		panel.add(lblMdp);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(54, 160, 278, 19);
		panel.add(passwordField);
		
		JButton btnSeConnecter = new JButton("Se connecter");
		btnSeConnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField.getText().length() > 0 && passwordField.getPassword().length > 0) {
					authentification_db(textField.getText(), String.valueOf(passwordField.getPassword()));
				} else {
					JOptionPane.showMessageDialog(new JFrame(), "Veuillez entrer un email et un mot de passe.", "Erreur",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSeConnecter.setForeground(Color.BLACK);
		btnSeConnecter.setBounds(125, 212, 154, 21);
		panel.add(btnSeConnecter);
		²
		JButton btnMdpOublie = new JButton("Mot de passe oublié ?");
		btnMdpOublie.setForeground(Color.BLUE);
		btnMdpOublie.setBounds(125, 232, 154, 21);
		panel.add(btnMdpOublie);
		
		JLabel lblConnexion = new JLabel("New label");
		lblConnexion.setVisible(false);
		lblConnexion.setForeground(Color.RED);
		lblConnexion.setBounds(54, 189, 359, 13);
		panel.add(lblConnexion);
	}
	
	

	@SuppressWarnings("null")
	public void authentification_db(String email, String mdp) {
		ConnexionDAO connexion = new ConnexionDAO();
		int[] rs = {-1,-1};
		JLabel lblConnexion = null;
		try {
			rs = connexion.getConnexion(email, mdp);	
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		switch(rs[0]) {
		case -1:
			lblConnexion.setText("Erreur !Mauvais mot de passe ou email !");
			break;
		case 0:
			dispose();
			new MenuEtudiant();
			break;
		case 1:
			dispose();
			new MenuEnseignant();
			break;
		case 2:
			dispose();
			new MenuAdministrateur();
			break;
		case 3:
			dispose();
			new MenuGestionnaire();
			break;
		}
	}
}
