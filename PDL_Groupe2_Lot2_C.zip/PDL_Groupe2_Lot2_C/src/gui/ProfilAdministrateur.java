package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProfilAdministrateur {

	private JFrame frmProfilAdministrateur;
	private JTextField nom_textField;
	private JTextField prenom_textField;
	private JTextField email_textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfilAdministrateur window = new ProfilAdministrateur();
					window.frmProfilAdministrateur.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ProfilAdministrateur() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProfilAdministrateur = new JFrame();
		frmProfilAdministrateur.setTitle("Profil Administrateur");
		frmProfilAdministrateur.setBounds(100, 100, 541, 278);
		frmProfilAdministrateur.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProfilAdministrateur.getContentPane().setLayout(null);
		
		JLabel nom = new JLabel("Nom");
		nom.setBounds(58, 23, 223, 13);
		frmProfilAdministrateur.getContentPane().add(nom);
		
		nom_textField = new JTextField();
		nom_textField.setEditable(false);
		nom_textField.setBounds(58, 46, 203, 19);
		frmProfilAdministrateur.getContentPane().add(nom_textField);
		nom_textField.setColumns(10);
		
		JLabel prenom = new JLabel("Prénom");
		prenom.setBounds(58, 75, 203, 13);
		frmProfilAdministrateur.getContentPane().add(prenom);
		
		prenom_textField = new JTextField();
		prenom_textField.setEditable(false);
		prenom_textField.setBounds(58, 98, 203, 19);
		frmProfilAdministrateur.getContentPane().add(prenom_textField);
		prenom_textField.setColumns(10);
		
		JLabel email = new JLabel("Email");
		email.setBounds(58, 127, 185, 13);
		frmProfilAdministrateur.getContentPane().add(email);
		
		email_textField = new JTextField();
		email_textField.setEditable(false);
		email_textField.setBounds(58, 150, 203, 19);
		frmProfilAdministrateur.getContentPane().add(email_textField);
		email_textField.setColumns(10);
		
		JLabel mdp = new JLabel("Mot de passe");
		mdp.setBounds(58, 179, 165, 13);
		frmProfilAdministrateur.getContentPane().add(mdp);
		
		passwordField = new JPasswordField();
		passwordField.setEditable(false);
		passwordField.setBounds(58, 202, 203, 19);
		frmProfilAdministrateur.getContentPane().add(passwordField);
		
		JButton btnModifierInfos = new JButton("Modifier");
		
		btnModifierInfos.setBounds(325, 97, 165, 21);
		frmProfilAdministrateur.getContentPane().add(btnModifierInfos);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MenuAdmin();
				frmProfilAdministrateur.dispose();
			}
		});
		btnRetour.setBounds(379, 201, 111, 21);
		frmProfilAdministrateur.getContentPane().add(btnRetour);
		
		JButton btnConfirmer = new JButton("Confirmer");
		btnConfirmer.setVisible(false);
		btnConfirmer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(false);
				passwordField.setEditable(false);
				btnModifierInfos.setVisible(true);
				btnConfirmer.setVisible(false);
			}
		});
		btnConfirmer.setBounds(325, 149, 165, 21);
		frmProfilAdministrateur.getContentPane().add(btnConfirmer);
		
		btnModifierInfos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(true);
				passwordField.setEditable(true);
				btnModifierInfos.setVisible(false);
				btnConfirmer.setVisible(true);
			}
		});
	}
}
