package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ProfilEnseignant extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frmProfilEnseignant;
	private JTextField nom_textField;
	private JTextField prenom_textField;
	private JTextField email_textField;
	private JTextField numTel_textField;
	private JPasswordField passwordField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfilEnseignant window = new ProfilEnseignant();
					window.frmProfilEnseignant.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ProfilEnseignant() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProfilEnseignant = new JFrame();
		frmProfilEnseignant.setTitle("Profil Enseignant");
		frmProfilEnseignant.setBounds(100, 100, 590, 299);
		frmProfilEnseignant.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProfilEnseignant.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		frmProfilEnseignant.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel nom = new JLabel("Nom");
		nom.setBounds(47, 21, 104, 13);
		panel.add(nom);
		
		nom_textField = new JTextField();
		nom_textField.setEnabled(false);
		nom_textField.setEditable(false);
		nom_textField.setColumns(10);
		nom_textField.setBounds(47, 38, 260, 19);
		panel.add(nom_textField);
		
		JLabel prenom = new JLabel("Prénom");
		prenom.setBounds(47, 67, 104, 13);
		panel.add(prenom);
		
		prenom_textField = new JTextField();
		prenom_textField.setEditable(false);
		prenom_textField.setColumns(10);
		prenom_textField.setBounds(47, 84, 260, 19);
		panel.add(prenom_textField);
		
		JLabel email = new JLabel("Email");
		email.setBounds(47, 113, 104, 13);
		panel.add(email);
		
		email_textField = new JTextField();
		email_textField.setEditable(false);
		email_textField.setColumns(10);
		email_textField.setBounds(47, 130, 260, 19);
		panel.add(email_textField);
		
		JLabel motDePasse = new JLabel("Mot de passe");
		motDePasse.setBounds(47, 159, 104, 13);
		panel.add(motDePasse);
		
		JLabel numTel = new JLabel("Numéro de téléphone");
		numTel.setBounds(47, 204, 104, 13);
		panel.add(numTel);
		
		numTel_textField = new JTextField();
		numTel_textField.setEditable(false);
		numTel_textField.setColumns(10);
		numTel_textField.setBounds(47, 221, 260, 19);
		panel.add(numTel_textField);
		
		passwordField = new JPasswordField();
		passwordField.setEditable(false);
		passwordField.setBounds(47, 175, 260, 19);
		panel.add(passwordField);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MenuEns();
				dispose();
			}
		});
		btnRetour.setBounds(464, 219, 85, 21);
		panel.add(btnRetour);
		
		JButton btnModifierInfos = new JButton("Modifier");
		
		btnModifierInfos.setBounds(384, 129, 165, 19);
		panel.add(btnModifierInfos);
		
		JButton btnConfirmer = new JButton("Confirmer");
		btnConfirmer.setVisible(false);
		btnConfirmer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(false);
				passwordField.setEditable(false);
				numTel_textField.setEditable(false);
				btnModifierInfos.setVisible(true);
				btnConfirmer.setVisible(false);
			}
		});
		btnConfirmer.setBounds(384, 173, 165, 21);
		panel.add(btnConfirmer);
		
		btnModifierInfos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email_textField.setEditable(true);
				passwordField.setEditable(true);
				numTel_textField.setEditable(true);
				btnModifierInfos.setVisible(false);
				btnConfirmer.setVisible(true);
			}
		});
	}
}
