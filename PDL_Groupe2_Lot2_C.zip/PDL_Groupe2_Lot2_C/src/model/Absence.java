package model;

/**
 * @author coren
 *
 */
public class Absence {
	private String date;
	private double nbHeures;
	private String type;
	private String justificatif;
	private boolean justifiee;
	
	/**
	 * @param date
	 * @param nbHeures
	 * @param type
	 * @param justificatif
	 * @param justifiee
	 */
	public Absence(String date, double nbHeures, String type, String justificatif, boolean justifiee) {
		this.date = date;
		this.nbHeures = nbHeures;
		this.type = type;
		this.justificatif = justificatif;
		this.justifiee = justifiee;
	}

	/**
	 * @return
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return
	 */
	public double getNbHeures() {
		return nbHeures;
	}

	/**
	 * @param nbHeures
	 */
	public void setNbHeures(double nbHeures) {
		this.nbHeures = nbHeures;
	}

	/**
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return
	 */
	public String getJustificatif() {
		return justificatif;
	}

	/**
	 * @param justificatif
	 */
	public void setJustificatif(String justificatif) {
		this.justificatif = justificatif;
	}

	/**
	 * @return
	 */
	public boolean isJustifiee() {
		return justifiee;
	}

	/**
	 * @param justifiee
	 */
	public void setJustifiee(boolean justifiee) {
		this.justifiee = justifiee;
	}
	
	public void display () {
		System.out.printf("Date : "+date+"\nNombre d'heures : "+nbHeures+"\nType : "+type+"\nJustificatif : "+justificatif+"\nAbsence justifiée ? "+ justifiee);
	}

}