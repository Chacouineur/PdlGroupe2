package model;

import java.util.ArrayList;

/**
 * @author coren
 *
 */
public class Cours {
	private int nombreEtudiants;
	private int masseHorraire;
	private String nom;
	private Enseignant enseignant;
	private ArrayList<Etudiant> etudiants;
	private ArrayList<String> planningHebdomadaire;
	
	/**
	 * @param nombreEtudiants
	 * @param masseHorraire
	 * @param nom
	 * @param enseignant
	 * @param etudiants
	 * @param planningHebdomadaire
	 */
	public Cours(int nombreEtudiants, int masseHorraire, String nom, Enseignant enseignant,
			ArrayList<Etudiant> etudiants, ArrayList<String> planningHebdomadaire) {
		this.nombreEtudiants = nombreEtudiants;
		this.masseHorraire = masseHorraire;
		this.nom = nom;
		this.enseignant = enseignant;
		this.etudiants = etudiants;
		this.planningHebdomadaire = planningHebdomadaire;
	}

	/**
	 * @return
	 */
	public int getNombreEtudiants() {
		return nombreEtudiants;
	}

	/**
	 * @param nombreEtudiants
	 */
	public void setNombreEtudiants(int nombreEtudiants) {
		this.nombreEtudiants = nombreEtudiants;
	}

	/**
	 * @return
	 */
	public int getMasseHorraire() {
		return masseHorraire;
	}

	/**
	 * @param masseHorraire
	 */
	public void setMasseHorraire(int masseHorraire) {
		this.masseHorraire = masseHorraire;
	}

	/**
	 * @return
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @param nom
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return
	 */
	public Enseignant getEnseignant() {
		return enseignant;
	}

	/**
	 * @param enseignant
	 */
	public void setEnseignant(Enseignant enseignant) {
		this.enseignant = enseignant;
	}

	/**
	 * @return
	 */
	public ArrayList<Etudiant> getEtudiants() {
		return etudiants;
	}

	/**
	 * @param etudiants
	 */
	public void setEtudiants(ArrayList<Etudiant> etudiants) {
		this.etudiants = etudiants;
	}

	/**
	 * @return
	 */
	public ArrayList<String> getPlanningHebdomadaire() {
		return planningHebdomadaire;
	}

	/**
	 * @param planningHebdomadaire
	 */
	public void setPlanningHebdomadaire(ArrayList<String> planningHebdomadaire) {
		this.planningHebdomadaire = planningHebdomadaire;
	}
	
	
	
}