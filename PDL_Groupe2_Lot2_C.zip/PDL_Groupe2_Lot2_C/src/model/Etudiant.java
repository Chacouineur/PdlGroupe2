package model;

 /**
 * @author coren
 *
 */
public class Etudiant  extends Utilisateur{
	private String filiere;
	private int groupe;


	/**
	 * @param id
	 * @param nom
	 * @param prenom
	 * @param adresseElectronique
	 * @param mdp
	 * @param filiere
	 * @param groupe
	 */
	public Etudiant(long id,String nom, String prenom, String adresseElectronique, String mdp, String filiere, int groupe) {
		super(id, nom,prenom,adresseElectronique,mdp);
		this.filiere = filiere;
		this.groupe = groupe;
	}

	/**
	 * @return
	 */
	public String getFiliere() {
		return filiere;
	}

	/**
	 * @param filiere
	 */
	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}

	/**
	 * @return
	 */
	public int getGroupe() {
		return groupe;
	}

	/**
	 * @param groupe
	 */
	public void setGroupe(int groupe) {
		this.groupe = groupe;
	}
	
	
	/**
	 *
	 */
	@Override
	public String toString() {
		return "Etudiant [filiere=" + filiere + ", groupe=" + groupe + ", nom=" + nom + ", prenom=" + prenom
				+ ", adresseElectronique=" + adresseElectronique + ", mdp=" + mdp + "]";
	}

	/**
	 *
	 */
	public void display () {
		System.out.printf(toString());
	}
}
