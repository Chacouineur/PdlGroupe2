package model;

/**
 * @author coren
 *
 */
public class Utilisateur {
	protected long id;
	protected String nom;
	protected String prenom;
	protected String adresseElectronique;
	protected String mdp;

	/**
	 * @param id
	 * @param nom
	 * @param prenom
	 * @param adresseElectronique
	 * @param mdp
	 */
	public Utilisateur(long id, String nom, String prenom, String adresseElectronique, String mdp) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.adresseElectronique = adresseElectronique;
		this.mdp = mdp;
	}
	/**
	 * @return
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @return
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * @param prenom
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	/**
	 * @return
	 */
	public String getAdresseElectronique() {
		return adresseElectronique;
	}
	/**
	 * @param adresseElectronique
	 */
	public void setAdresseElectronique(String adresseElectronique) {
		this.adresseElectronique = adresseElectronique;
	}
	/**
	 * @return
	 */
	public String getMdp() {
		return mdp;
	}
	/**
	 * @param mdp
	 */
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	
	@Override
	public String toString() {
		return "Utilisateur [nom=" + nom + ", prenom=" + prenom + ", adresseElectronique=" + adresseElectronique
				+ ", mdp=" + mdp + "]";
	}
	public void display() {
		System.out.println(toString());
	}
}
