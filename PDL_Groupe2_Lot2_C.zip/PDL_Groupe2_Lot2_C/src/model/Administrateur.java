package model;

/**
 * @author coren
 *
 */
public class Administrateur extends Utilisateur{


	/**
	 * @param id
	 * @param nom
	 * @param prenom
	 * @param adresseElectronique
	 * @param mdp
	 */
	public Administrateur( long id,String nom, String prenom, String adresseElectronique, String mdp) {
		super(id, nom, prenom, adresseElectronique, mdp);
	}
		
	public void display () {
		super.display();
	}
	
}
