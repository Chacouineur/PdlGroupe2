package model;

/**
 * @author coren
 *
 */
public class Gestionnaire extends Utilisateur{

	/**
	 * @param nom
	 * @param prenom
	 * @param adresseElectronique
	 * @param mdp
	 * @param id 
	 */
	public Gestionnaire( long id,String nom, String prenom, String adresseElectronique, String mdp) {
		super(id, nom, prenom, adresseElectronique, mdp);
	}

	/**
	 *
	 */
	public void display () {
		super.display();
	}

}
