package model;

/**
 * @author coren
 *
 */
public class Enseignant  extends Utilisateur{
	private String numTelephone;


	/**
	 * @param id
	 * @param nom
	 * @param prenom
	 * @param adresseElectronique
	 * @param mdp
	 * @param numTelephone
	 */
	public Enseignant(long id,String nom, String prenom, String adresseElectronique, String mdp,String numTelephone) {
		super(id, nom,prenom,adresseElectronique,mdp);
		this.numTelephone = numTelephone;
	}

	/**
	 * @return
	 */
	public String getNumTelephone() {
		return numTelephone;
	}

	/**
	 * @param numTelephone
	 */
	public void setNumTelephone(String numTelephone) {
		this.numTelephone = numTelephone;
	}
	
	@Override
	public String toString() {
		return "Enseignant [numTelephone=" + numTelephone + ", nom=" + nom + ", prenom=" + prenom
				+ ", adresseElectronique=" + adresseElectronique + ", mdp=" + mdp + "]";
	}

	public void display () {
		System.out.printf(toString());
	}
	
}
